#ifndef _ENC_DEC_H_
#define _ENC_DEC_H_

#include <string.h>

void EncDecString(char * InputString, const char * Key, 
						char * OutputString);

#endif

